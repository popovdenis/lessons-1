<?php
/**
 * Created by PhpStorm.
 * User: Denis
 * Date: 07.11.2015
 * Time: 11:12
 */
interface ILogger
{
    public function log($message);
}