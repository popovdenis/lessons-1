<?php
/**
 * Created by PhpStorm.
 * User: Denis
 * Date: 07.11.2015
 * Time: 11:26
 */
class Wife implements IFoodProvider
{
    public function getFood()
    {
        // ...
        return $food;
    }
}


//class Wife implements IFoodProvider{
//    public function getFood() {
//        // ...
//        return $food;
//    }
//}