<?php
/**
 * Created by PhpStorm.
 * User: Denis
 * Date: 07.11.2015
 * Time: 11:04
 */

/**
 * SOLID
 * D - принцип инверсии зависимостей
 * Dependency Inversion Principle
 */
